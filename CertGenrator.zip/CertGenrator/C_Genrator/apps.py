from django.apps import AppConfig


class CGenratorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'C_Genrator'
